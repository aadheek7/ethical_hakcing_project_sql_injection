# in the app values will be applied in the query like:
email = # E-mail received from the html file
password = # Password received from the html file
" SELECT secret FROM users WHERE email = '{email}' AND password = '{password}' "


#_________________________________________________________________________________________________________
# SQL Query with clean email
clean_email = "adhikesavan20051004@gmail.com"
email = clean_email

" SELECT secret FROM users WHERE email = 'adhikesavan20051004@gmail.com' AND password = 'xyz!@#$%' "

'''
Checks wether both email AND password exists
if both exists then condtion becomes TRUE AND TRUE = TRUE
if password doesn't exists then condition becomes TRUE AND FALSE = FALSE (login will fail!)
'''
#_________________________________________________________________________________________________________

#_________________________________________________________________________________________________________
# SQL Query with sql injected email ('#)
sql_injected_email = "adhikesavan20051004@gmail.com'#"
email = sql_injected_email

" SELECT secret FROM users WHERE email = 'adhikesavan20051004@gmail.com'#' AND password = 'randomincorrectpassword' "

'''
Checks wether only email exists as the password part got commented out it's ignored!
'''
#_________________________________________________________________________________________________________

