const express = require("express");
const nodemailer = require("nodemailer");
const cors = require("cors");
const mysql = require("mysql2");

const app = express();
app.use(express.json());
app.use(cors());

// ✅ MySQL connection
const db = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "passwdofadhik7",
  database: "user_infos"
});

db.connect(err => {
  if (err) {
    console.log("DB connection failed:", err);
  } else {
    console.log("Connected to MySQL ✅");
  }
});

// ================= OTP =================
let otpStore = {};

const transporter = nodemailer.createTransport({
  service: "gmail",
  auth: {
    user: "adhikesavan20051004@gmail.com",
    pass: "ndzx qfdu xtcg pnao"
  }
});

app.post("/send-otp", async (req, res) => {
  const { email } = req.body;

  const otp = Math.floor(100000 + Math.random() * 900000);
  otpStore[email] = otp;

  try {
    await transporter.sendMail({
      from: "adhikesavan20051004@gmail.com",
      to: email,
      subject: "Your OTP",
      text: `OTP: ${otp}`
    });

    res.json({ success: true });
  } catch (err) {
    res.json({ success: false });
  }
});

app.post("/verify-otp", (req, res) => {
  const { email, otp } = req.body;

  if (otpStore[email] == otp) {
    res.json({ success: true });
  } else {
    res.json({ success: false });
  }
});

// ================= SIGNUP =================
app.post("/signup", (req, res) => {
  const { username, email, password } = req.body;

  const query = `INSERT INTO users (username, email, password)
                 VALUES ('${username}', '${email}', '${password}')`;

  db.query(query, (err) => {
    if (err) {
      console.log(err);
      return res.json({ success: false });
    }

    // Return the newly created user so the frontend can store it (mirrors login)
    db.query(`SELECT * FROM users WHERE email='${email}'`, (err2, rows) => {
      if (err2 || rows.length === 0) return res.json({ success: true });
      res.json({ success: true, user: rows[0] });
    });
  });
});

// ================= SAVE SECRET =================
app.post("/save-secret", (req, res) => {
  const { email, secret } = req.body;

  const query = `UPDATE users SET secret='${secret}' WHERE email='${email}'`;

  db.query(query, (err) => {
    if (err) {
      console.log(err);
      return res.json({ success: false });
    }

    res.json({ success: true });
  });
});

// ================= LOGIN (VULNERABLE) =================
app.post("/login", (req, res) => {
  const { email, password } = req.body;

  const query = `SELECT * FROM users WHERE email='${email}' AND password='${password}'`;

  db.query(query, (err, result) => {
    if (err) return res.json({ success: false });

    if (result.length > 0) {
      res.json({ success: true, user: result[0] });
    } else {
      res.json({ success: false });
    }
  });
});

// ================= START =================
app.listen(3000, () => {
  console.log("Server running on http://localhost:3000");
});

/*
sql injection 1(space at end) displays the first user in the table: (@' OR '1'='1' -- )
sql injection 2(space at end) display the user with email: (adhikesavan20051004@gmail.com' -- )
*/