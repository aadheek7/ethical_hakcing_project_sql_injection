// CAPTCHA
let currentCaptcha = "";
window.otpVerified = false;

function generateCaptcha() {
  const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
  let captcha = "";

  for (let i = 0; i < 5; i++) {
    captcha += chars[Math.floor(Math.random() * chars.length)];
  }

  document.getElementById("captchaText").innerText = captcha;
  currentCaptcha = captcha;
}

window.onload = function () {
  generateCaptcha();
};

// PASSWORD TOGGLE
function togglePassword(fieldId, icon) {
  const input = document.getElementById(fieldId);

  if (input.type === "password") {
    input.type = "text";
    icon.textContent = "👀";
  } else {
    input.type = "password";
    icon.textContent = "🙈";
  }
}

// OTP
function sendOTP() {
  const email = document.getElementById("email").value;

  fetch("http://localhost:3000/send-otp", {
    method: "POST",
    headers: {"Content-Type": "application/json"},
    body: JSON.stringify({ email })
  })
  .then(res => res.json())
  .then(data => {
    if (data.success) alert("OTP sent!");
  });
}

function verifyOTP() {
  const email = document.getElementById("email").value;
  const otp = document.getElementById("otp-input").value;

  fetch("http://localhost:3000/verify-otp", {
    method: "POST",
    headers: {"Content-Type": "application/json"},
    body: JSON.stringify({ email, otp })
  })
  .then(res => res.json())
  .then(data => {
    if (data.success) {
      alert("OTP Verified!");
      window.otpVerified = true;
    } else {
      alert("Invalid OTP!");
    }
  });
}

// sql preview
function updateSQLPreview() {
  const email = document.getElementById("login-email").value;
  const password = document.getElementById("login-password").value;

  let query = `mysql> SELECT secret FROM users WHERE email = '${email}' AND password = '${password}'`;

  function isOutsideQuotes(index) {
    let before = query.substring(0, index);
    let quoteCount = (before.match(/'/g) || []).length;
    return quoteCount % 2 === 0; // even = outside string
  }

  let hashIndex = query.indexOf("#");
  let dashIndex = query.indexOf("-- ");

  let validIndexes = [];

  if (hashIndex !== -1 && isOutsideQuotes(hashIndex)) {
    validIndexes.push(hashIndex);
  }

  if (dashIndex !== -1 && isOutsideQuotes(dashIndex)) {
    validIndexes.push(dashIndex);
  }

  let commentIndex = validIndexes.length > 0 ? Math.min(...validIndexes) : -1;

  // 🎨 Apply highlighting
  if (commentIndex !== -1) {
    const normalPart = query.substring(0, commentIndex);
    const commentPart = query.substring(commentIndex);

    document.getElementById("sqlPreview").innerHTML =
      normalPart + `<span class="comment">${commentPart}</span>`;
  } else {
    document.getElementById("sqlPreview").innerText = query;
  }
}

// SIGNUP
function validateForm() {
  const username = document.getElementById("name").value;
  const email = document.getElementById("email").value;
  const password = document.getElementById("password").value;
  const repassword = document.getElementById("repassword").value;
  const captcha = document.getElementById("captcha").value;

  if (captcha === "") { alert("Captcha is required!"); return false; }
  if (captcha !== currentCaptcha) { alert("Invalid Captcha!"); return false; }

  if (username === "") { alert("Username required"); return false; }

  if (email === "") { alert("E-mail is required!"); return false; }
  if (email.includes(" ")) { alert("E-mail cannot contain spaces!"); return false; }
  if (!email.includes("@")) { alert("Please enter a valid E-mail!"); return false; }

  if (password === "") {alert("Password is required!"); return false;}
  if (password.includes(" ")) { alert("Password cannot contain spaces!"); return false; }
  if (password.length < 8) { alert("Password must be at least 8 characters!"); return false; }
  if (repassword === "") { alert("Re-enter and confirm the password!"); return false; }
  if (password !== repassword) { alert("Passwords don't match"); return false; }

  if (!window.otpVerified) { alert("Verify OTP first"); return false; }

  // ✅ Your fetch signup call here
  fetch("http://localhost:3000/signup", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ username, email, password })
  })
  .then(res => res.json())
  .then(data => {
    if (data.success) {
      localStorage.setItem("user", JSON.stringify(data.user));
      alert("Signup successful!");
      window.location.href = "app.html";
    } else {
      alert("Signup failed!");
    }
  });

  return false; // ✅ VERY IMPORTANT: prevents page reload
}

// LOGIN (FOR SQL INJECTION DEMO)
function validateLogin() {
  const captcha = document.getElementById("captcha").value;
  const email = document.getElementById("login-email").value;
  const password = document.getElementById("login-password").value;

  if (captcha === "") { alert("Captcha is required!"); return false; }
  if (captcha !== currentCaptcha) { alert("Invalid Captcha!"); return false; }


  if (email === "") { alert("E-mail is required!"); return false; }
  if (!email.includes("@")) { alert("Please enter a valid E-mail!"); return false; }

  if (password === "") {alert("Password is required!"); return false; }
  if (password.includes(" ")) { alert("Password cannot contain spaces!"); return false; }
  if (password.length < 8) { alert("Password must be at least 8 characters!"); return false; }

  fetch("http://localhost:3000/login", {
    method: "POST",
    headers: {"Content-Type": "application/json"},
    body: JSON.stringify({ email, password })
  })
  .then(res => res.json())
  .then(data => {
    if (data.success) {
      localStorage.setItem("user", JSON.stringify(data.user));
      window.location.href = "app.html";
    } else {
      alert("Login failed! Incorrect e-mail or password!");
    }
  });

  return false;
}

// event listener for sql preview
window.addEventListener("DOMContentLoaded", () => {
  const emailInput = document.getElementById("login-email");
  const passwordInput = document.getElementById("login-password");

  if (emailInput && passwordInput) {
    emailInput.addEventListener("input", updateSQLPreview);
    passwordInput.addEventListener("input", updateSQLPreview);
  }
});